using Microsoft.AspNetCore.Mvc;
using Newmark.Api;
using Newmark.Api.Models;

namespace Newmark.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PropertiesController : ControllerBase
{
    private readonly BlobService _blobService;

    public PropertiesController(BlobService blobService)
    {
        _blobService = blobService;
    }

    [HttpGet]
    public async Task<ActionResult<List<Property>>> GetProperties()
    {
        try
        {
            var properties = await _blobService.GetPropertiesAsync();
            return Ok(properties);
        }
        catch (HttpRequestException ex)
        {
            return StatusCode(503, $"Error accessing blob: {ex.Message}");
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }
}
