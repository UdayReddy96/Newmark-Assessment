using System.Collections.Generic;

namespace Newmark.Api.Models;

public class Property
{
    public string Name { get; set; } = string.Empty;
    public List<string> Features { get; set; } = new();
    public List<string> Highlights { get; set; } = new();
    public List<string> Transportation { get; set; } = new();
    public List<Space> Spaces { get; set; } = new();
}
