namespace Newmark.Api.Models;

public class RentRoll
{
    public string Month { get; set; } = string.Empty;
    public decimal Amount { get; set; }
}
