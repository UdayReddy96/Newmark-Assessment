using System.Collections.Generic;

namespace Newmark.Api.Models;

public class Space
{
    public string Name { get; set; } = string.Empty;
    public List<RentRoll> RentRolls { get; set; } = new();
}
