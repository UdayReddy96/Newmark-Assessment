using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Newmark.Api.Models;

public class BlobService
{
    private readonly HttpClient _httpClient;

    public BlobService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Property>> GetPropertiesAsync()
    {
        var blobUrl = "https://nmrkpidev.blob.core.windows.net/dev-test/devtest.json";
        var sasToken = "?sp=r&st=2024-10-28T10:35:48Z&se=2025-10-28T18:35:48Z&spr=https&sv=2022-11-02&sr=b&sig=bdeoPWtefikVgUGFCUs4ihsl22ZhQGu4%2B4cAfoMwd4k%3D";

        var fullUrl = $"{blobUrl}{sasToken}";

        try
        {
            var response = await _httpClient.GetAsync(fullUrl);

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"Failed to fetch blob: {response.StatusCode}");
            }

            var content = await response.Content.ReadAsStringAsync();

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var properties = JsonSerializer.Deserialize<List<Property>>(content, options);
            return properties ?? new List<Property>();
        }
        catch (Exception ex)
        {
            throw new ApplicationException("Error accessing blob data", ex);
        }
    }
}
