import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [properties, setProperties] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [expandedProperties, setExpandedProperties] = useState({});
  const [expandedSpaces, setExpandedSpaces] = useState({});

  useEffect(() => {
    fetch('https://localhost:7096/api/properties') // <-- adjust port if needed
      .then((res) => {
        if (!res.ok) {
          throw new Error(`API error: ${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        setProperties(data);
        setError(null);
      })
      .catch((err) => {
        console.error('Failed to fetch properties:', err);
        setError('Failed to fetch properties. Is the API running? Check browser console.');
      })
      .finally(() => setLoading(false));
  }, []);

  const toggleProperty = (index) => {
    setExpandedProperties(prev => ({ ...prev, [index]: !prev[index] }));
  };

  const toggleSpace = (pIndex, sIndex) => {
    const key = `${pIndex}-${sIndex}`;
    setExpandedSpaces(prev => ({ ...prev, [key]: !prev[key] }));
  };

  if (loading) return <div className="text-white p-4">Loading...</div>;
  if (error) return <div className="text-red-500 p-4">{error}</div>;

  return (
    <div className="p-6 text-white bg-gray-900 min-h-screen">
      <h1 className="text-3xl font-bold mb-4">Newmark Properties</h1>
      {properties.map((property, pIndex) => (
        <div key={pIndex} className="mb-4 p-4 bg-gray-800 rounded-lg shadow-md">
          <div
            className="cursor-pointer font-semibold text-xl"
            onClick={() => toggleProperty(pIndex)}
          >
            {expandedProperties[pIndex] ? '▼' : '▶'} {property.propertyName}
          </div>

          {expandedProperties[pIndex] && (
            <div className="ml-4 mt-2 space-y-2">
              <p><strong>Features:</strong> {property.features?.join(', ')}</p>
              <p><strong>Highlights:</strong> {property.highlights?.join(', ')}</p>
              <p><strong>Transportation:</strong> {property.transportation?.join(', ')}</p>

              <div className="mt-2">
                <strong>Spaces:</strong>
                {property.spaces?.map((space, sIndex) => (
                  <div key={sIndex} className="ml-4 mt-1 border-l-2 pl-3 border-gray-500">
                    <div
                      className="cursor-pointer font-medium"
                      onClick={() => toggleSpace(pIndex, sIndex)}
                    >
                      {expandedSpaces[`${pIndex}-${sIndex}`] ? '▼' : '▶'} {space.spaceName}
                    </div>
                    {expandedSpaces[`${pIndex}-${sIndex}`] && (
                      <div className="ml-4">
                        {Object.entries(space.rentRoll || {}).map(([month, amount]) => (
                          <p key={month}>{month}: ${amount}</p>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

export default App;
